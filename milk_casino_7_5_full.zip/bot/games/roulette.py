
import random
def spin():
    return random.randint(0,36)
