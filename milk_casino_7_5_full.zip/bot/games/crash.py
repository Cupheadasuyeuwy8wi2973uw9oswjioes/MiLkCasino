
import random
def gen():
    return round(random.uniform(1.1,5),2)
