
import random
def new():
    return {"bombs": random.sample(range(25), 5)}
