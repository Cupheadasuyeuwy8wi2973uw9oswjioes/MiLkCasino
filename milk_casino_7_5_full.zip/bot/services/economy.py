
from database.db import get_user, set_user

def add(uid, amount):
    bal = get_user(uid)
    set_user(uid, bal + amount)

def take(uid, amount):
    bal = get_user(uid)
    set_user(uid, bal - amount)
