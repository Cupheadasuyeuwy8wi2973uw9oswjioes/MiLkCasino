
from telegram.ext import CommandHandler
from bot.games import crash, roulette, dice

async def crash_cmd(update, ctx):
    await update.message.reply_text(f"🚀 x{crash.gen()}")

async def roulette_cmd(update, ctx):
    await update.message.reply_text(f"🎡 {roulette.spin()}")

async def dice_cmd(update, ctx):
    await update.message.reply_text(f"🎲 {dice.roll()}")

def setup(app):
    app.add_handler(CommandHandler("crash", crash_cmd))
    app.add_handler(CommandHandler("roulette", roulette_cmd))
    app.add_handler(CommandHandler("dice", dice_cmd))
