
from telegram.ext import CommandHandler
from database.db import cur

async def admin(update, ctx):
    c = cur.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    await update.message.reply_text(f"👑 Users: {c}")

def setup(app):
    app.add_handler(CommandHandler("admin", admin))
