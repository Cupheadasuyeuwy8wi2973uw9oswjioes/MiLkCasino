
from telegram.ext import CommandHandler

async def deposit(update, ctx):
    await update.message.reply_text("⭐ Stars payment (подключи провайдера)")

def setup(app):
    app.add_handler(CommandHandler("deposit", deposit))
