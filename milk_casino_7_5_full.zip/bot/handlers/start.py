
from telegram.ext import CommandHandler
from telegram import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from config.settings import WEB_URL

async def start(update, ctx):
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🎮 Играть", web_app=WebAppInfo(url=WEB_URL))]
    ])
    await update.message.reply_text("🥛 MiLK Casino 7.5", reply_markup=kb)

def setup(app):
    app.add_handler(CommandHandler("start", start))
