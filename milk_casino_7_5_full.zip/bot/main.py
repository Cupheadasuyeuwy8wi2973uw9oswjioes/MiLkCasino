
from telegram.ext import ApplicationBuilder
from config.settings import TOKEN
from bot.handlers import start, games, admin, payments

def run():
    app = ApplicationBuilder().token(TOKEN).build()
    start.setup(app)
    games.setup(app)
    admin.setup(app)
    payments.setup(app)
    app.run_polling()

if __name__ == "__main__":
    run()
