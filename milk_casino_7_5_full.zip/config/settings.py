
TOKEN = "PUT_TOKEN"
WEB_URL = "https://your-replit-url.repl.co"
START_BALANCE = 1000
