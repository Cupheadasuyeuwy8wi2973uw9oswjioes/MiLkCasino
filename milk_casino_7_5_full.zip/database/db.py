
import sqlite3
conn = sqlite3.connect("db.db", check_same_thread=False)
cur = conn.cursor()

cur.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, balance INTEGER)")
conn.commit()

def get_user(uid):
    cur.execute("SELECT balance FROM users WHERE id=?", (uid,))
    r = cur.fetchone()
    if not r:
        cur.execute("INSERT INTO users VALUES (?,?)", (uid,1000))
        conn.commit()
        return 1000
    return r[0]

def set_user(uid, bal):
    cur.execute("UPDATE users SET balance=? WHERE id=?", (bal, uid))
    conn.commit()
